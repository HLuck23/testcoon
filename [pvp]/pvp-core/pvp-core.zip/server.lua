-- ============================================================
-- SERVER-SIDE PvP ENFORCER
-- Ensures friendly fire is enabled for every connecting player.
-- Also broadcasts kill feed to all players.
-- ============================================================

AddEventHandler("onResourceStart", function(res)
    if res ~= GetCurrentResourceName() then return end

    -- Apply to all currently connected players
    for _, playerId in ipairs(GetPlayers()) do
        TriggerClientEvent("pvp-core:enableFriendlyFire", tonumber(playerId))
    end
end)

AddEventHandler("playerSpawned", function()
    -- Re-enable PvP every spawn just in case
    TriggerClientEvent("pvp-core:enableFriendlyFire", source)
end)

-- ============================================================
-- KILL FEED BROADCASTER
-- Receives kill events from any client and broadcasts to all.
-- ============================================================

RegisterNetEvent("pvp-core:sendKillFeed")
AddEventHandler("pvp-core:sendKillFeed", function(victimName, weaponCategory, isHeadshot)
    local src = source
    local killerName = GetPlayerName(src)

    -- Broadcast to every client (including sender)
    TriggerClientEvent("pvp-core:addKillFeed", -1, killerName, victimName, weaponCategory, isHeadshot)
end)
