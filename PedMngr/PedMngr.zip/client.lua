-- ============================================================
-- PedMngr v2.4 — Model-specific outfits, model memory, shirt/pants icons, rotation
-- ============================================================

local FREEMODE_MODELS = {
    [GetHashKey("mp_m_freemode_01")] = true,
    [GetHashKey("mp_f_freemode_01")] = true,
}

local PM = {
    open = false,
    camera = nil,
    oldPos = nil,
    oldHeading = nil,
    forceOpen = false,
    serverAppearance = nil,
    lastPedModel = nil,
    hasNotifiedReady = false,
    autoSaveTimer = 0,

    models = {
        { name = "Male",   hash = GetHashKey("mp_m_freemode_01"), id = "mp_m_freemode_01" },
        { name = "Female", hash = GetHashKey("mp_f_freemode_01"), id = "mp_f_freemode_01" },
    },

    categories = {
        {
            name = "Head",
            items = {
                {id = 2,  name = "Hair",       max = 78},
                {id = 1,  name = "Mask",       max = 169},
                {id = 0,  name = "Face",       max = 45},
            }
        },
        {
            name = "Upper Body",
            items = {
                {id = 11, name = "Jacket / Top", max = 334},
                {id = 8,  name = "Undershirt",   max = 164},
                {id = 3,  name = "Arms / Torso", max = 183},
                {id = 9,  name = "Armor / Vest", max = 18},
            }
        },
        {
            name = "Lower Body",
            items = {
                {id = 4,  name = "Pants",   max = 325},
                {id = 6,  name = "Shoes",   max = 89},
            }
        },
        {
            name = "Accessories",
            items = {
                {id = 5,  name = "Bag",         max = 82},
                {id = 7,  name = "Accessories", max = 121},
                {id = 10, name = "Decals",      max = 110},
            }
        },
    },

    props = {
        {id = 0, name = "Hat",       max = 160},
        {id = 1, name = "Glasses",   max = 35},
        {id = 2, name = "Ears",      max = 18},
        {id = 6, name = "Watch",     max = 30},
        {id = 7, name = "Bracelet",  max = 10},
    },

    faceFeatures = {
        {id = 0,  name = "Nose Width",        group = "Nose"},
        {id = 1,  name = "Nose Peak Height",  group = "Nose"},
        {id = 2,  name = "Nose Peak Length",  group = "Nose"},
        {id = 3,  name = "Nose Bone Height",  group = "Nose"},
        {id = 4,  name = "Nose Peak Lower",   group = "Nose"},
        {id = 5,  name = "Nose Bone Twist",   group = "Nose"},
        {id = 6,  name = "Eyebrow Height",    group = "Eyes"},
        {id = 7,  name = "Eyebrow Depth",     group = "Eyes"},
        {id = 11, name = "Eye Opening",       group = "Eyes"},
        {id = 12, name = "Lip Thickness",     group = "Mouth"},
        {id = 15, name = "Chin Height",       group = "Jaw / Chin"},
        {id = 16, name = "Chin Depth",        group = "Jaw / Chin"},
        {id = 17, name = "Chin Width",        group = "Jaw / Chin"},
        {id = 18, name = "Chin Dimple",       group = "Jaw / Chin"},
        {id = 13, name = "Jaw Bone Width",    group = "Jaw / Chin"},
        {id = 14, name = "Jaw Bone Depth",    group = "Jaw / Chin"},
        {id = 8,  name = "Cheekbone Height",  group = "Cheeks"},
        {id = 9,  name = "Cheekbone Width",   group = "Cheeks"},
        {id = 10, name = "Cheek Width",       group = "Cheeks"},
        {id = 19, name = "Neck Thickness",    group = "Neck"},
    },

    overlays = {
        {id = 0,  name = "Blemishes",          max = 23, hasColor = false},
        {id = 1,  name = "Facial Hair",        max = 28, hasColor = true,  colorType = 1},
        {id = 2,  name = "Eyebrows",           max = 33, hasColor = true,  colorType = 1},
        {id = 3,  name = "Ageing",             max = 14, hasColor = false},
        {id = 4,  name = "Makeup",             max = 74, hasColor = false},
        {id = 5,  name = "Blush",              max = 6,  hasColor = true,  colorType = 2},
        {id = 6,  name = "Complexion",         max = 11, hasColor = false},
        {id = 7,  name = "Sun Damage",         max = 10, hasColor = false},
        {id = 8,  name = "Lipstick",           max = 9,  hasColor = true,  colorType = 2},
        {id = 9,  name = "Moles / Freckles",   max = 17, hasColor = false},
        {id = 10, name = "Chest Hair",         max = 16, hasColor = true,  colorType = 1},
        {id = 11, name = "Body Blemishes",     max = 11, hasColor = false},
        {id = 12, name = "Add Body Blemishes", max = 11, hasColor = false},
    },

    hairColors = {
        {0, "Black"}, {1, "Dark Brown"}, {2, "Brown"}, {3, "Light Brown"},
        {4, "Blonde"}, {5, "Dirty Blonde"}, {6, "Platinum"}, {7, "Gray"},
        {8, "Silver"}, {9, "White"}, {10, "Red"}, {11, "Orange"},
        {12, "Green"}, {13, "Blue"}, {14, "Purple"}, {15, "Pink"},
        {16, "Burgundy"}, {17, "Auburn"}, {18, "Light Red"}, {19, "Dark Red"},
        {20, "Chestnut"}, {21, "Honey"}, {22, "Golden"}, {23, "Strawberry"},
        {24, "Copper"}, {25, "Lavender"}, {26, "Teal"}, {27, "Turquoise"},
        {28, "Emerald"}, {29, "Navy"}, {30, "Coral"}, {31, "Peach"},
        {32, "Rose"}, {33, "Magenta"}, {34, "Lime"}, {35, "Olive"},
        {36, "Dark Gray"}, {37, "Charcoal"}, {38, "Ash"}, {39, "Champagne"},
        {40, "Ivory"}, {41, "Pale Blonde"}, {42, "Light Gray"}, {43, "Snow White"},
        {44, "Jet Black"}, {45, "Espresso"}, {46, "Chocolate"}, {47, "Caramel"},
        {48, "Sandy"}, {49, "Platinum Blonde"}, {50, "Pastel Pink"},
        {51, "Pastel Blue"}, {52, "Pastel Green"}, {53, "Pastel Purple"},
        {54, "Neon Pink"}, {55, "Neon Blue"}, {56, "Neon Green"},
        {57, "Neon Orange"}, {58, "Neon Red"}, {59, "Neon Yellow"},
        {60, "Neon Purple"}, {61, "Bright Red"}, {62, "Bright Blue"},
        {63, "Bright Green"},
    },
}

-- ============================================================
-- CAMERA VIEW PRESETS
-- ============================================================

local CAMERA_VIEWS = {
    full  = { dist = 3.5, zOff = 0.3, lookZ = 0.0 },
    head  = { dist = 0.8, zOff = 0.6, lookZ = 0.6 },
    chest = { dist = 1.6, zOff = 0.4, lookZ = 0.15 },
    legs  = { dist = 2.2, zOff = -0.2, lookZ = -0.55 },
}

local currentCamView = 'full'

local function SetCameraView(viewName)
    if not PM.camera then return end
    currentCamView = viewName
    local view = CAMERA_VIEWS[viewName] or CAMERA_VIEWS.full
    local ped = PlayerPedId()
    local coords = GetEntityCoords(ped)
    local angle = math.rad(180)
    local offset = vector3(math.sin(angle) * view.dist, math.cos(angle) * view.dist, view.zOff)
    SetCamCoord(PM.camera, coords.x + offset.x, coords.y + offset.y, coords.z + offset.z)
    PointCamAtEntity(PM.camera, ped, 0.0, 0.0, view.lookZ, true)
end

-- ============================================================
-- SAFE MAX HELPERS
-- ============================================================

local function GetSafeMaxDrawable(componentId)
    local ped = PlayerPedId()
    local hardMax = 255
    for _, cat in ipairs(PM.categories) do
        for _, item in ipairs(cat.items) do
            if item.id == componentId then hardMax = item.max break end
        end
    end
    local actualMax = GetNumberOfPedDrawableVariations(ped, componentId) - 1
    return math.min(hardMax, math.max(0, actualMax))
end

local function GetSafeMaxProp(propId)
    local ped = PlayerPedId()
    local hardMax = 255
    for _, prop in ipairs(PM.props) do
        if prop.id == propId then hardMax = prop.max break end
    end
    local actualMax = GetNumberOfPedPropDrawableVariations(ped, propId) - 1
    return math.min(hardMax, math.max(0, actualMax))
end

-- ============================================================
-- NUI CALLBACKS
-- ============================================================

RegisterNUICallback('close', function(_, cb) ClosePedMngr() cb('ok') end)

RegisterNUICallback('setComponent', function(data, cb)
    local ped = PlayerPedId()
    local componentId = tonumber(data.componentId)
    local drawable = tonumber(data.drawable)
    local texture = tonumber(data.texture) or 0
    local safeMax = GetSafeMaxDrawable(componentId)
    if drawable > safeMax then drawable = safeMax end
    SetPedComponentVariation(ped, componentId, drawable, texture, 0)
    local maxTex = GetNumberOfPedTextureVariations(ped, componentId, drawable) - 1
    cb({ maxTexture = math.max(0, maxTex) })
end)

RegisterNUICallback('setProp', function(data, cb)
    local ped = PlayerPedId()
    local id = tonumber(data.propId)
    local drawable = tonumber(data.drawable)
    local texture = tonumber(data.texture) or 0
    if drawable == -1 then
        ClearPedProp(ped, id)
        cb({ maxTexture = 0 })
    else
        local safeMax = GetSafeMaxProp(id)
        if drawable > safeMax then drawable = safeMax end
        SetPedPropIndex(ped, id, drawable, texture, true)
        local maxTex = GetNumberOfPedPropTextureVariations(ped, id, drawable) - 1
        cb({ maxTexture = math.max(0, maxTex) })
    end
end)

RegisterNUICallback('setHairColor', function(data, cb)
    SetPedHairColor(PlayerPedId(), tonumber(data.color), tonumber(data.highlight) or tonumber(data.color))
    cb('ok')
end)

RegisterNUICallback('setFaceFeature', function(data, cb)
    SetPedFaceFeature(PlayerPedId(), tonumber(data.index), tonumber(data.scale))
    cb('ok')
end)

RegisterNUICallback('setHeadBlend', function(data, cb)
    SetPedHeadBlendData(PlayerPedId(), data.shapeFirst or 0, data.shapeSecond or 0, 0,
        data.skinFirst or 0, data.skinSecond or 0, 0, data.shapeMix or 0.5, data.skinMix or 0.5, 0.0, false)
    cb('ok')
end)

RegisterNUICallback('setEyeColor', function(data, cb)
    SetPedEyeColor(PlayerPedId(), tonumber(data.color) or 0)
    cb('ok')
end)

RegisterNUICallback('rotatePed', function(data, cb)
    SetEntityHeading(PlayerPedId(), tonumber(data.heading) or 180.0)
    cb('ok')
end)

RegisterNUICallback('rotatePedDelta', function(data, cb)
    local ped = PlayerPedId()
    local current = GetEntityHeading(ped)
    local delta = tonumber(data.delta) or 25.0
    SetEntityHeading(ped, (current + delta) % 360.0)
    cb('ok')
end)

RegisterNUICallback('setCameraView', function(data, cb)
    SetCameraView(data.view or 'full')
    cb('ok')
end)

RegisterNUICallback('randomize', function(_, cb)
    RandomizePed()
    cb({ currentData = BuildCurrentDataWithInfo() })
end)

RegisterNUICallback('resetFit', function(_, cb)
    ResetToDefault()
    cb({ currentData = BuildCurrentDataWithInfo() })
end)

RegisterNUICallback('refresh', function(_, cb)
    cb({ currentData = BuildCurrentDataWithInfo() })
end)

-- ============================================================
-- NUI CALLBACK — setPedModel (with model memory)
-- ============================================================

RegisterNUICallback('setPedModel', function(data, cb)
    local newModel = tonumber(data.model)
    if not newModel then
        cb({ currentData = BuildCurrentDataWithInfo() })
        return
    end

    local ped = PlayerPedId()
    local currentModel = GetEntityModel(ped)
    if currentModel == newModel then
        cb({ currentData = BuildCurrentDataWithInfo() })
        return
    end

    -- Save current model's appearance before switching
    TriggerServerEvent('pedmngr:saveModelAppearance', currentModel, GetCurrentData())

    RequestModel(newModel)
    local timeout = 0
    while not HasModelLoaded(newModel) and timeout < 100 do
        Wait(10)
        timeout = timeout + 1
    end

    if HasModelLoaded(newModel) then
        SetPlayerModel(PlayerId(), newModel)
        SetModelAsNoLongerNeeded(newModel)
        Wait(200)

        ped = PlayerPedId()
        SetPedDefaultComponentVariation(ped)

        if FREEMODE_MODELS[newModel] then
            SetPedHeadBlendData(ped, 0, 0, 0, 0, 0, 0, 0.5, 0.5, 0.0, false)
            SetPedHairColor(ped, 0, 0)
            SetPedEyeColor(ped, 0)
            for _, ff in ipairs(PM.faceFeatures) do
                SetPedFaceFeature(ped, ff.id, 0.0)
            end
            for i = 0, 12 do
                SetPedHeadOverlay(ped, i, 255, 0.0)
            end
        end

        -- Request saved appearance for new model (server will apply via pedmngr:applyData)
        TriggerServerEvent('pedmngr:loadModelAppearance', newModel)
    end

    cb({ currentData = BuildCurrentDataWithInfo() })
end)

-- ============================================================
-- NUI CALLBACK — setOverlay
-- ============================================================

RegisterNUICallback('setOverlay', function(data, cb)
    local ped = PlayerPedId()
    local overlayId = tonumber(data.index)
    local value = tonumber(data.value) or 255
    local opacity = tonumber(data.opacity) or 0.0
    local color = tonumber(data.color)
    local color2 = tonumber(data.color2)
    local colorType = tonumber(data.colorType)

    SetPedHeadOverlay(ped, overlayId, value, opacity)
    if colorType and color and value ~= 255 then
        SetPedHeadOverlayColor(ped, overlayId, colorType, color, color2 or color)
    end
    cb('ok')
end)

-- ============================================================
-- NUI CALLBACKS — Outfits (server-synced, model-specific)
-- ============================================================

RegisterNUICallback('saveOutfit', function(data, cb)
    if data.name and data.name ~= "" then
        TriggerServerEvent('pedmngr:saveOutfit', data.name, GetEntityModel(PlayerPedId()), GetCurrentData())
    end
    cb({ outfits = {} })
end)

RegisterNUICallback('updateOutfit', function(data, cb)
    if data.name and data.name ~= "" then
        TriggerServerEvent('pedmngr:updateOutfit', data.name, GetEntityModel(PlayerPedId()), GetCurrentData())
    end
    cb({ outfits = {} })
end)

RegisterNUICallback('loadOutfit', function(data, cb)
    if data.name then
        TriggerServerEvent('pedmngr:loadOutfit', data.name, GetEntityModel(PlayerPedId()))
    end
    cb({ currentData = BuildCurrentDataWithInfo() })
end)

RegisterNUICallback('deleteOutfit', function(data, cb)
    if data.name then
        TriggerServerEvent('pedmngr:deleteOutfit', data.name, GetEntityModel(PlayerPedId()))
    end
    cb({ outfits = {} })
end)

RegisterNUICallback('listOutfits', function(_, cb)
    TriggerServerEvent('pedmngr:listOutfits', GetEntityModel(PlayerPedId()))
    cb({ outfits = {} })
end)

-- ============================================================
-- NUI CALLBACK — Save Character
-- ============================================================

RegisterNUICallback('saveCharacter', function(_, cb)
    local appearanceData = GetCurrentData()
    TriggerServerEvent('pedmngr:saveAppearance', appearanceData)
    ClosePedMngr()
    cb('ok')
end)

-- ============================================================
-- GET / APPLY / RANDOMIZE / RESET
-- ============================================================

function GetCurrentData()
    local ped = PlayerPedId()
    local model = GetEntityModel(ped)

    local d = {
        model = model,
        components = {},
        props = {},
        faceFeatures = {},
        headBlend = {},
        overlays = {},
        hairColor = 0,
        hairHighlight = 0,
        eyeColor = 0,
        hairStyle = 0,
    }

    for _, cat in ipairs(PM.categories) do
        for _, item in ipairs(cat.items) do
            d.components[tostring(item.id)] = {
                drawable = GetPedDrawableVariation(ped, item.id),
                texture = GetPedTextureVariation(ped, item.id)
            }
        end
    end

    for _, prop in ipairs(PM.props) do
        d.props[tostring(prop.id)] = {
            drawable = GetPedPropIndex(ped, prop.id),
            texture = GetPedPropTextureIndex(ped, prop.id)
        }
    end

    local sf, ss, _, skf, sks, _, sm, skm, _, _ = GetPedHeadBlendData(ped)
    d.headBlend = { shapeFirst = sf, shapeSecond = ss, skinFirst = skf, skinSecond = sks, shapeMix = sm, skinMix = skm }

    for _, ff in ipairs(PM.faceFeatures) do
        d.faceFeatures[tostring(ff.id)] = GetPedFaceFeature(ped, ff.id)
    end

    for i = 0, 12 do
        local success, overlayValue, colourType, firstColour, secondColour, overlayOpacity = GetPedHeadOverlayData(ped, i)
        if success then
            d.overlays[tostring(i)] = {
                value = overlayValue,
                opacity = overlayOpacity,
                colorType = colourType,
                color = firstColour,
                color2 = secondColour,
            }
        else
            d.overlays[tostring(i)] = { value = 255, opacity = 0.0 }
        end
    end

    d.eyeColor = GetPedEyeColor(ped)
    d.hairStyle = GetPedDrawableVariation(ped, 2)

    local hc, hh = GetPedHairColor(ped)
    d.hairColor = hc
    d.hairHighlight = hh

    return d
end

function BuildCurrentDataWithInfo()
    local ped = PlayerPedId()
    local d = GetCurrentData()
    d.compInfo = {}
    d.propInfo = {}
    d.overlayInfo = {}

    for _, cat in ipairs(PM.categories) do
        for _, item in ipairs(cat.items) do
            local safeMax = GetSafeMaxDrawable(item.id)
            local drawable = GetPedDrawableVariation(ped, item.id)
            if drawable > safeMax then drawable = safeMax end
            local maxTex = GetNumberOfPedTextureVariations(ped, item.id, drawable) - 1
            d.compInfo[tostring(item.id)] = {
                maxDrawable = safeMax,
                maxTexture = math.max(0, maxTex)
            }
        end
    end

    for _, prop in ipairs(PM.props) do
        local safeMax = GetSafeMaxProp(prop.id)
        local drawable = GetPedPropIndex(ped, prop.id)
        local maxTex = 0
        if drawable >= 0 then
            maxTex = GetNumberOfPedPropTextureVariations(ped, prop.id, drawable) - 1
        end
        d.propInfo[tostring(prop.id)] = {
            maxDrawable = safeMax,
            maxTexture = math.max(0, maxTex)
        }
    end

    for _, ov in ipairs(PM.overlays) do
        d.overlayInfo[tostring(ov.id)] = { maxValue = ov.max, hasColor = ov.hasColor }
    end

    return d
end

function ApplyData(data)
    if not data then return end
    local ped = PlayerPedId()

    if data.model then
        local currentModel = GetEntityModel(ped)
        if currentModel ~= data.model then
            RequestModel(data.model)
            local timeout = 0
            while not HasModelLoaded(data.model) and timeout < 100 do
                Wait(10)
                timeout = timeout + 1
            end
            if HasModelLoaded(data.model) then
                SetPlayerModel(PlayerId(), data.model)
                SetModelAsNoLongerNeeded(data.model)
                Wait(200)
                ped = PlayerPedId()
            end
        end
    end

    if data.components then
        for id, vals in pairs(data.components) do
            SetPedComponentVariation(ped, tonumber(id), vals.drawable or 0, vals.texture or 0, 0)
        end
    end

    if data.props then
        for id, vals in pairs(data.props) do
            if vals.drawable == -1 then
                ClearPedProp(ped, tonumber(id))
            else
                SetPedPropIndex(ped, tonumber(id), vals.drawable or 0, vals.texture or 0, true)
            end
        end
    end

    if data.headBlend then
        local hb = data.headBlend
        SetPedHeadBlendData(ped, hb.shapeFirst or 0, hb.shapeSecond or 0, 0,
            hb.skinFirst or 0, hb.skinSecond or 0, 0, hb.shapeMix or 0.5, hb.skinMix or 0.5, 0.0, false)
    end

    if data.faceFeatures then
        for id, scale in pairs(data.faceFeatures) do
            SetPedFaceFeature(ped, tonumber(id), scale or 0.0)
        end
    end

    if data.overlays then
        for id, vals in pairs(data.overlays) do
            local overlayId = tonumber(id)
            SetPedHeadOverlay(ped, overlayId, vals.value or 255, vals.opacity or 0.0)
            if vals.colorType and vals.color and (vals.value or 255) ~= 255 then
                SetPedHeadOverlayColor(ped, overlayId, vals.colorType, vals.color, vals.color2 or vals.color)
            end
        end
    end

    if data.eyeColor then SetPedEyeColor(ped, data.eyeColor) end

    if data.hairColor or data.hairHighlight then
        SetPedHairColor(ped, data.hairColor or 0, data.hairHighlight or 0)
    end
end

function RandomizePed()
    local ped = PlayerPedId()
    for _, cat in ipairs(PM.categories) do
        for _, item in ipairs(cat.items) do
            local safeMax = GetSafeMaxDrawable(item.id)
            local applied = false
            if safeMax >= 0 then
                for _ = 1, 20 do
                    local drawable = math.random(0, safeMax)
                    local texMax = GetNumberOfPedTextureVariations(ped, item.id, drawable) - 1
                    local texture = 0
                    if texMax > 0 then texture = math.random(0, math.min(4, texMax)) end
                    if IsPedComponentVariationValid(ped, item.id, drawable, texture) then
                        SetPedComponentVariation(ped, item.id, drawable, texture, 0)
                        applied = true
                        break
                    end
                end
            end
            if not applied then SetPedComponentVariation(ped, item.id, 0, 0, 0) end
        end
    end

    for _, prop in ipairs(PM.props) do
        if math.random() > 0.6 then
            local safeMax = GetSafeMaxProp(prop.id)
            if safeMax >= 0 then
                local pd = math.random(0, safeMax)
                local ptMax = GetNumberOfPedPropTextureVariations(ped, prop.id, pd) - 1
                local pt = ptMax > 0 and math.random(0, math.min(3, ptMax)) or 0
                SetPedPropIndex(ped, prop.id, pd, pt, true)
            else
                ClearPedProp(ped, prop.id)
            end
        else
            ClearPedProp(ped, prop.id)
        end
    end

    SetPedHeadBlendData(ped, math.random(0, 45), math.random(0, 45), 0,
        math.random(0, 45), math.random(0, 45), 0, math.random(), math.random(), 0.0, false)

    for _, ff in ipairs(PM.faceFeatures) do
        SetPedFaceFeature(ped, ff.id, (math.random() * 2 - 1))
    end

    for _, ov in ipairs(PM.overlays) do
        if math.random() > 0.5 then
            local val = math.random(0, ov.max)
            local op = 0.3 + (math.random() * 0.7)
            SetPedHeadOverlay(ped, ov.id, val, op)
            if ov.hasColor and ov.colorType then
                SetPedHeadOverlayColor(ped, ov.id, ov.colorType, math.random(0, 63), math.random(0, 63))
            end
        else
            SetPedHeadOverlay(ped, ov.id, 255, 0.0)
        end
    end

    SetPedHairColor(ped, math.random(0, 63), math.random(0, 63))
    SetPedEyeColor(ped, math.random(0, 31))
end

function ResetToDefault()
    local ped = PlayerPedId()
    SetPedComponentVariation(ped, 11, 15, 0, 0)
    SetPedComponentVariation(ped, 8, 15, 0, 0)
    SetPedComponentVariation(ped, 3, 15, 0, 0)
    SetPedComponentVariation(ped, 4, 14, 0, 0)
    SetPedComponentVariation(ped, 6, 1, 0, 0)
    SetPedComponentVariation(ped, 1, 0, 0, 0)
    SetPedComponentVariation(ped, 5, 0, 0, 0)
    SetPedComponentVariation(ped, 7, 0, 0, 0)
    SetPedComponentVariation(ped, 9, 0, 0, 0)
    SetPedComponentVariation(ped, 10, 0, 0, 0)
    for _, p in ipairs(PM.props) do ClearPedProp(ped, p.id) end
    for i = 0, 12 do SetPedHeadOverlay(ped, i, 255, 0.0) end
end

-- ============================================================
-- OPEN / CLOSE
-- ============================================================

function OpenPedMngr()
    if PM.open then return end
    PM.open = true

    local ped = PlayerPedId()
    PM.oldPos = GetEntityCoords(ped)
    PM.oldHeading = GetEntityHeading(ped)

    FreezeEntityPosition(ped, true)
    SetEntityCollision(ped, false, false)
    SetPlayerInvincible(PlayerId(), true)

    -- Create camera with FULL BODY default view
    local coords = PM.oldPos
    PM.camera = CreateCamWithParams("DEFAULT_SCRIPTED_CAMERA",
        coords.x, coords.y, coords.z,
        0.0, 0.0, 0.0, 35.0, false, 0)
    SetCamActive(PM.camera, true)
    RenderScriptCams(true, true, 500, false, false)

    -- Set default full-body view
    SetCameraView('full')

    SetEntityHeading(ped, 180.0)

    local flatComponents = {}
    for _, cat in ipairs(PM.categories) do
        for _, item in ipairs(cat.items) do
            local safeMax = GetSafeMaxDrawable(item.id)
            table.insert(flatComponents, { id = item.id, name = item.name, max = safeMax })
        end
    end

    local enrichedProps = {}
    for _, prop in ipairs(PM.props) do
        local safeMax = GetSafeMaxProp(prop.id)
        table.insert(enrichedProps, { id = prop.id, name = prop.name, max = safeMax })
    end

    local modelList = {}
    for _, m in ipairs(PM.models) do
        table.insert(modelList, { name = m.name, hash = m.hash, id = m.id })
    end

    SetNuiFocus(true, true)
    SendNUIMessage({
        action = 'open',
        components = flatComponents,
        props = enrichedProps,
        overlays = PM.overlays,
        pedModels = modelList,
        hairColors = PM.hairColors,
        currentData = BuildCurrentDataWithInfo(),
        savedOutfits = {},
        forceOpen = PM.forceOpen,
    })

    TriggerServerEvent('pedmngr:listOutfits', GetEntityModel(PlayerPedId()))
end

function ClosePedMngr()
    if not PM.open then return end
    PM.open = false
    PM.forceOpen = false

    if PM.camera then
        SetCamActive(PM.camera, false)
        DestroyCam(PM.camera, false)
        PM.camera = nil
    end
    RenderScriptCams(false, true, 500, false, false)

    local ped = PlayerPedId()
    FreezeEntityPosition(ped, false)
    SetEntityCollision(ped, true, true)
    SetPlayerInvincible(PlayerId(), false)

    SetNuiFocus(false, false)
    SendNUIMessage({ action = 'close' })

    -- Auto-save current appearance when closing editor
    TriggerServerEvent('pedmngr:saveAppearance', GetCurrentData())
end

-- ============================================================
-- COMMANDS
-- ============================================================

RegisterCommand("register", function() OpenPedMngr() end, false)
RegisterCommand("appearance", function() OpenPedMngr() end, false)

-- ============================================================
-- SERVER EVENTS
-- ============================================================

RegisterNetEvent('pedmngr:applyAppearance')
AddEventHandler('pedmngr:applyAppearance', function(data)
    PM.serverAppearance = data
    if data then
        ApplyData(data)
    end
end)

RegisterNetEvent('pedmngr:openEditor')
AddEventHandler('pedmngr:openEditor', function()
    PM.forceOpen = true
    Citizen.CreateThread(function()
        Wait(2000)
        OpenPedMngr()
    end)
end)

RegisterNetEvent('pedmngr:applyData')
AddEventHandler('pedmngr:applyData', function(data)
    if data then ApplyData(data) end
    if PM.open then
        SendNUIMessage({
            action = 'refreshData',
            data = BuildCurrentDataWithInfo()
        })
    end
end)

RegisterNetEvent('pedmngr:outfitList')
AddEventHandler('pedmngr:outfitList', function(names)
    SendNUIMessage({
        action = 'outfitList',
        outfits = names
    })
end)

RegisterNetEvent('pedmngr:appearanceSaved')
AddEventHandler('pedmngr:appearanceSaved', function()
    PM.forceOpen = false

end)

-- ============================================================
-- PED CHANGE DETECTION — Re-apply appearance after respawn
-- FIX: Don't re-apply when editor is open (model switcher)
-- ============================================================

Citizen.CreateThread(function()
    while true do
        Wait(1000)
        -- SKIP if editor is open (prevents model switcher from reverting)
        if PM.open then
            PM.lastPedModel = GetEntityModel(PlayerPedId())
            goto continue
        end

        local ped = PlayerPedId()
        if DoesEntityExist(ped) then
            local model = GetEntityModel(ped)
            if PM.lastPedModel and PM.lastPedModel ~= model and PM.serverAppearance then
                Wait(500)
                ApplyData(PM.serverAppearance)
            end
            PM.lastPedModel = model
        end
        ::continue::
    end
end)

-- ============================================================
-- PERIODIC AUTO-SAVE — Silently saves appearance every 60s
-- This ensures rejoin always wears what you actually had on
-- ============================================================

Citizen.CreateThread(function()
    while true do
        Wait(60000) -- Every 60 seconds
        if not PM.open then
            PM.autoSaveTimer = PM.autoSaveTimer + 1
            -- Auto-save current appearance to server
            local data = GetCurrentData()
            TriggerServerEvent('pedmngr:saveAppearance', data)
            -- Also update the local cache so respawns get latest
            PM.serverAppearance = data
        end
    end
end)

-- ============================================================
-- INIT
-- ============================================================

AddEventHandler("onClientResourceStart", function(res)
    if res ~= GetCurrentResourceName() then return end


    Citizen.CreateThread(function()
        local attempts = 0
        local maxAttempts = 30

        while attempts < maxAttempts do
            Wait(500)
            attempts = attempts + 1

            local ped = PlayerPedId()
            if DoesEntityExist(ped) and ped ~= -1 then
                local model = GetEntityModel(ped)
                if FREEMODE_MODELS[model] then
                    if not PM.hasNotifiedReady then
                        PM.hasNotifiedReady = true
                        PM.lastPedModel = model
                        TriggerServerEvent('pedmngr:playerReady')
                    end
                    return
                end
            end
        end

        if not PM.hasNotifiedReady then
            PM.hasNotifiedReady = true
            TriggerServerEvent('pedmngr:playerReady')
        end
    end)
end)

AddEventHandler("playerSpawned", function()
    if not PM.hasNotifiedReady then
        PM.hasNotifiedReady = true
        Citizen.CreateThread(function()
            Wait(2000)
            local ped = PlayerPedId()
            if DoesEntityExist(ped) then
                PM.lastPedModel = GetEntityModel(ped)
            end
            TriggerServerEvent('pedmngr:playerReady')
        end)
    end
end)
